﻿using MaterialDesignThemes.Wpf;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Windows;
namespace Login_Interface
{
    public partial class MainWindow : Window
    {
        private readonly string connectionString = "server=localhost;database=test;uid=sa;pwd=961121";

        public MainWindow()
        {
            InitializeComponent();
            
        }

        // 注册按钮点击事件处理程序
        private void signupBtn_Click(object sender, RoutedEventArgs e)
        {
            string username = txtUserName.Text;
            string password = txtPassword.Password;

            try
            {
                // 检查用户名是否已经存在
                if (IsUsernameExists(username))
                {
                    MessageBox.Show("该用户名已经存在！", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                // 执行用户注册
                if (RegisterUser(username, password))
                {
                    MessageBox.Show("注册成功!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    MessageBox.Show("注册失败！", "Failure", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while registering user: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // 登录按钮点击事件处理程序
        private void loginBtn_Click(object sender, RoutedEventArgs e)
        {
            string username = txtUserName.Text;
            string password = txtPassword.Password;

            if (AuthenticateUser(username, password))
            {
                MessageBox.Show("登录成功!");
                // 这里可以执行登录成功后的操作，比如打开主窗口
            }
            else
            {
                MessageBox.Show("用户名或者密码错误！");
            }
        }

        // 检查用户名是否已经存在
        private bool IsUsernameExists(string username)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT COUNT(*) FROM [User] WHERE Username = @Username";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Username", username);
                    int count = (int)cmd.ExecuteScalar();
                    return count > 0;
                }
            }
        }

        // 注册用户
        private bool RegisterUser(string username, string password)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string commandStr = "INSERT INTO [User] (Username, Password) VALUES (@Username, @Password)";
                SqlCommand sqlCmd = new SqlCommand(commandStr, conn);
                sqlCmd.Parameters.AddWithValue("@Username", username);
                sqlCmd.Parameters.AddWithValue("@Password", password);
                int rowsAffected = sqlCmd.ExecuteNonQuery();
                return rowsAffected > 0;
            }
        }

        // 验证用户
        private bool AuthenticateUser(string username, string password)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT COUNT(*) FROM [User] WHERE Username = @Username AND Password = @Password";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Username", username);
                    cmd.Parameters.AddWithValue("@Password", password);
                    int count = (int)cmd.ExecuteScalar();
                    return count > 0;
                }
            }
        }

        // 退出按钮点击事件处理程序
        private void btnExit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        // 允许窗口拖动
        protected override void OnMouseLeftButtonDown(System.Windows.Input.MouseButtonEventArgs e)
        {
            base.OnMouseLeftButtonDown(e);
            DragMove();
        }


        //亮色与暗色模式切换
        public bool IsDarkTheme { get; set; }
        private readonly PaletteHelper paletteHelper = new PaletteHelper();

        private void themeToggle_Click(object sender, RoutedEventArgs e)
        {
            ITheme theme = paletteHelper.GetTheme();

            if (IsDarkTheme = theme.GetBaseTheme() == BaseTheme.Dark)
            {
                IsDarkTheme = false;
                theme.SetBaseTheme(Theme.Light);
            }
            else
            {
                IsDarkTheme = true;
                theme.SetBaseTheme(Theme.Dark);
            }
            paletteHelper.SetTheme(theme);
        }
    }
}
